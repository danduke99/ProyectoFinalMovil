const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const app = express()
const port = 5000
const mysql = require('mysql');

//configuracion base de datos
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Hidarmes.2019',
    port: 3306,
    database: 'admisiones'

})
app.use(cors());
app.use(express.json())
app.use(bodyParser.urlencoded({extended: true}))

app.get("/api/get", (req,res) =>{

    const sqlSelect = "SELECT * FROM documentos "
    db.query(sqlSelect,(err,result)=>{
     res.send(result)
  
    });
  
  })

app.post("/api/insert", (req,res) =>{
const docNombre = req.body.doc_nombre;
const docDescripcion = req.body.doc_descripcion;
const docImagen = req.body.doc_imagen;
const docCosto = req.body.doc_costo;

  const sqlInsert = "INSERT INTO documentos (doc_nombre,doc_descripcion,doc_imagen,doc_costo) VALUES (?,?,?,?)"
  db.query(sqlInsert,[docNombre,docDescripcion,docImagen,docCosto],(err,result)=>{
    console.log(err)

  });

})

app.delete("/api/delete/:doc_nombre", (req,res) =>{
  const docNombre = req.params.doc_nombre;
  
    const sqlDelete = "DELETE FROM documentos WHERE doc_nombre = ?"
    db.query(sqlDelete,docNombre,(err,result)=>{
      console.log(err)
  
    });
  
  })
  app.put("/api/update", (req,res) =>{
    const docNombre = req.body.doc_nombre;
    const docDescripcion = req.body.doc_descripcion;
    const docImagen = req.body.doc_imagen;
    const docCosto = req.body.doc_costo;
    
      const sqlUpdate = "UPDATE SET documentos doc_nombre = ?"
      db.query(sqlUpdate,d[docNombre,docDescripcion,docImagen,docCosto],(err,result)=>{
        console.log(err)
    
      });
    
    })

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})